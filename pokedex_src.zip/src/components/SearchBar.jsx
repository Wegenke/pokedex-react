import { useState, useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function SearchBar() {
  const [inputValue, setInputValue] = useState("");
  const [allPokemon, setAllPokemon] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate()

  const handleFocus = () => {
    if (loaded) return;

    setLoading(true);

    fetch("https://pokeapi.co/api/v2/pokemon?limit=1350")
      .then(res => res.json())
      .then(json => {
        setAllPokemon(json.results);
        setLoaded(true);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  };

  const filteredPokemon = useMemo(() => {
    if (!inputValue) return [];

    return allPokemon.filter(pokemon =>
      pokemon.name
        .toLowerCase()
        .includes(inputValue.toLowerCase())
    );
  }, [allPokemon, inputValue]);

  const handleRandomon = () => {
    navigate(`/details/${Math.ceil(Math.random() * 1025)}`)
  }

  const handleEnter = (e) => {
    if (e.key === 'Enter') {
      handleSearch()
    }
  }

  const handleSearch = () => {
    filteredPokemon.length >= 1 ? navigate(`/details/${filteredPokemon[0].name}`) : alert("That is not a pokemon")
    setInputValue("")
    document.querySelector("#root").focus()
  }

  return (
    <div className="searchBar">
      <button id="randomButton" onClick={handleRandomon}>RANDOMON</button>
      <input list="pokemans" className="pokeSearch" id="pokefinder" placeholder="POKE NAME" value={inputValue} onChange={(e) => setInputValue(e.target.value)} onFocus={handleFocus} onKeyDown={handleEnter} />
      {loading && <p>Loading Pokémon...</p>}
      {inputValue && <datalist id='pokemans'>
        {filteredPokemon.map(pkmn => <option value={pkmn.name} key={pkmn.name}>{pkmn.name}</option>)}
      </datalist>}
      <button id="locateButton" onClick={handleSearch}>LOCATE</button>
    </div>
  );
}