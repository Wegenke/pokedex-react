import { useEffect, useState } from "react";

const cache = {};

export default function usePokemon(name) {
  const [data, setData] = useState(cache[name] || null);
  const [loading, setLoading] = useState(!cache[name]);

  useEffect(() => {
    if (!name) return;

    if (cache[name]) {
      setData(cache[name]);
      setLoading(false);
      return;
    }

    const controller = new AbortController();

    setLoading(true);

    fetch(`https://pokeapi.co/api/v2/pokemon/${name}`, {
      signal: controller.signal
    })
      .then(res => res.json())
      .then(json => {
        cache[name] = json;
        setData(json);
        setLoading(false);
      })
      .catch(err => {
        if (err.name !== "AbortError") {
          console.error(err);
        }
      });

    return () => controller.abort();
  }, [name]);

  return { data, loading };
}