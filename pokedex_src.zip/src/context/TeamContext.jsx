import { createContext } from "react";

// const TeamContext = createContext({team: {}, setTeam: () => {}})
const TeamContext = createContext()

export default TeamContext